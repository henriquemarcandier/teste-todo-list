<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TodoListsTasksController extends Controller
{
    //
}
