<?php $__env->startSection('content'); ?>
                <table id="example2" class="table table-bordered table-hover w-100">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($todoLists)): ?>
                            <?php $__currentLoopData = $todoLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="w-50"><?php echo e($value->name); ?></td>
                            <td class="w-50">
                                <img src="<?php echo e(env('APP_URL')); ?>img/lista.png" width="25" title="Tarefas da <?php echo e($value->name); ?>" style="cursor:pointer" onclick="location.href='<?php echo e(env('APP_URL')); ?>listTasks/<?php echo e($value->id); ?>'">
                                <img src="<?php echo e(env('APP_URL')); ?>img/editar.png" width="25" title="Editar <?php echo e($value->name); ?>" style="cursor:pointer" onclick="location.href='<?php echo e(env('APP_URL')); ?><?php echo e($value->id); ?>'">
                                <img src="<?php echo e(env('APP_URL')); ?>img/excluir.png" width="25" title="Excluir <?php echo e($value->name); ?>" style="cursor:pointer" onclick="if (confirm('Tem certeza que deseja excluir essa parte do dia?')){ location.href='<?php echo e(env('APP_URL')); ?>delete/<?php echo e($value->id); ?>'; }">
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\teste-todo-list\resources\views/index.blade.php ENDPATH**/ ?>